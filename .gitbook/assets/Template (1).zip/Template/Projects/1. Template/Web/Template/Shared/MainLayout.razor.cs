using FormObjects.WorkflowEngineClientFiles.Auth;
using Microsoft.AspNetCore.Components;
using System.Threading.Tasks;

namespace Carrent.Shared
{
    public partial class MainLayout
    {
      
    }
}